import pygame
import pygame.locals
from textSurface import TextSurface

"""
this class creates a input box for the user to enter their text
use TextSurface.create_text_surface(text) to create a surface for the text
you can find blit code by Ctrl+f "static text blit" or "input box blit"


I have disable spacebar for input. To chage that Ctrl+f "Check for backspace"
"""


class EndScreen():
    def __init__(self) -> None:
        self.end_screen()

    def end_screen(self):  
        pygame.init()
        statictext = TextSurface().create_text_surface(f"sample static text")
        self.clock = pygame.time.Clock()
        # it will display on screen
        self.window = pygame.display.set_mode([1280, 960]) # set screen size to 1280x960
        # basic font for user typed
        self.base_font = pygame.font.Font(None, 32)
        self.user_name = ''
        # create rectangle
        input_rect = pygame.Rect(450,960/2, 140, 32)
        #set clicked text box  color
        color_active = pygame.Color(18,255,201)     
        #set not clicked text box color
        color_passive = pygame.Color(47,195,160)
        color = color_passive  
        active = False
        running = True
        pygame.key.set_repeat(500,100)
        while running:
            for event in pygame.event.get():
            # if user types QUIT then the screen will close
                if event.type == pygame.locals.QUIT:
                    running = False
        
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if input_rect.collidepoint(event.pos):
                        active = True
                    else:
                        active = False
                if event.type == pygame.KEYDOWN:
                    #checks if user has pressed enter if its enter then it will close the screen
                    if event.key == pygame.K_RETURN:
                        self.user_name
                        running = False
                    # Check for backspace
                    if event.key == pygame.K_BACKSPACE:
                        # get text input from 0 to -1 i.e. end.
                        self.user_name = self.user_name[:-1]

                    #This statement is currently limiting the user to 10 characters
                    #check for spacebar           
                    
                    #    vvvvvvvvvvvvvvvvvvvvvvvv change these if you want to change the max character limit
                    elif len(self.user_name) < 10 and event.key != pygame.K_SPACE:
                        #                             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^ remove these to enable spacebar input           
                        self.user_name += event.unicode
                        # Unicode standard is used for string
                        # formation
            
            # it will set background color of screen
            self.window.fill((255, 255, 255))
        
            if active:
                color = color_active
            else:
                color = color_passive
                
            # draw rectangle and argument passed which should
            # be on screen
            pygame.draw.rect(self.window, color, input_rect)
        
            text_surface = self.base_font.render(self.user_name, True, (0, 0, 0))
            
            # render at position stated in arguments
            self.window.blit(text_surface, (input_rect.x+5, input_rect.y+5)) #input box blit setting position
            self.window.blit(statictext, (450, 960/2 -50)) # static text blit cordination setting
            
            # set width of textfield so that text cannot get
            # outside of user's text input
            input_rect.w = max(100, text_surface.get_width()+10)
            
            # display.flip() will update only a portion of the
            # screen to updated, not full area
            pygame.display.flip()
            self.clock.tick(60)

EndScreen()